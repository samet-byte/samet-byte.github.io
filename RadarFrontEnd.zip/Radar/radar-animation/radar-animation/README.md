# Radar Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/devXprite/pen/oNPRKgW](https://codepen.io/devXprite/pen/oNPRKgW).

Neon Radar using SCSS